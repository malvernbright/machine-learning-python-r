# Datasets

### Datasets collected from R packages
 - mlbench 
 - kernlab
 - klaR
 - car
 - reshape2
 - hflights
 - ISLR
 
### The original source repositories are:
 - ftp://ftp.ics.uci.edu/pub/machine-learning-databases
 - http://www.ics.uci.edu/~mlearn/MLRepository.html
 - http://kdd.ics.uci.edu
 - http://www.liacs.nl/~putten/library/cc2000/ (ticdata)

